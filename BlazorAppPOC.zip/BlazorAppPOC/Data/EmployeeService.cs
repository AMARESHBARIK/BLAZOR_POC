﻿using System.Reflection.Metadata.Ecma335;

namespace BlazorAppPOC.Data
{
   
    public class EmployeeService:IEmployeeService
    {
        private List<Employee> employees = new List<Employee>
    {
        new Employee{ Id=Guid.NewGuid(), Name="E1"},
        new Employee{ Id=Guid.NewGuid(),Name="E2"}
    };

        public void AddEmployee(Employee employee)
        {
            var id = Guid.NewGuid();
            employee.Id = id;
            employees.Add(employee);
        }

        public void DeleteEmployee(Guid id)
        {
            var employee = GetEmployee(id);
            employees.Remove(employee);
        }

        public List<Employee> GetEmployee()
        {
            return employees;
        }

        public Employee GetEmployee(Guid id)
        {
            return employees.SingleOrDefault(x => x.Id == id);
        }

        public void UpdateEmployee(Employee employee)
        {
            Employee oldemp = GetEmployee(employee.Id);
            oldemp.Name = employee.Name;
        }
    }
}
