﻿using BlazorAppPOC.Pages;

namespace BlazorAppPOC.Data
{
    public interface IEmployeeService
    {
      List<Employee>  GetEmployee();
        
      Employee GetEmployee(Guid id);

       void UpdateEmployee(Employee employee);

        void AddEmployee(Employee employee);

        void DeleteEmployee(Guid id);
    }
}
